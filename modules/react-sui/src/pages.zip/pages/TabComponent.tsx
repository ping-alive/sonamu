import { camelize } from 'inflection';
import React, { useEffect, useState } from 'react';
import ReactJson from 'react-json-view';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import {
  Button,
  Dimmer,
  Loader,
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableHeaderCell,
  TableRow,
} from 'semantic-ui-react';
import { TypeframeTabProps } from 'src/pages/typeframe/TypeframeTabs';
import { Panel } from 'src/typeframe/components/Panel';

type TabComponent = {} & TypeframeTabProps;
export function TabComponent({ currentMdId, spec }: TabComponent) {
  return (
    <div className="tab-components">
      <Panel title="Components">
        <Table compact structured celled>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell>Key</Table.HeaderCell>
              <Table.HeaderCell>ComponentId</Table.HeaderCell>
              <Table.HeaderCell>Exists</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {(['view_list', 'view_form', 'view_search_input'] as const).map(
              (key) => (
                <Table.Row key={key}>
                  <Table.Cell collapsing>{key}</Table.Cell>
                  <Table.Cell>
                    {currentMdId + camelize(key.replace('view_', ''))}
                  </Table.Cell>
                  <Table.Cell>
                    <Button
                      size="mini"
                      color={spec.exists[key] ? 'grey' : 'purple'}
                    >
                      {spec.exists[key] ? '재생성' : '생성'}
                    </Button>
                  </Table.Cell>
                </Table.Row>
              ),
            )}
            {(
              [
                'view_enums_dropdown',
                'view_enums_select',
                'view_enums_buttonset',
              ] as const
            ).map((key) =>
              Object.entries(spec.enums).map(([enumName], index) => (
                <Table.Row key={`${key}__${enumName}`}>
                  {index === 0 && (
                    <Table.Cell rowSpan={Object.keys(spec.enums).length}>
                      {key}
                    </Table.Cell>
                  )}
                  <Table.Cell>
                    {enumName}
                    {camelize(key.replace('view_enums_', ''))}
                  </Table.Cell>
                  <Table.Cell collapsing>
                    <Button
                      size="mini"
                      color={
                        spec.exists[`${key}__${enumName}`] ? 'grey' : 'purple'
                      }
                    >
                      {spec.exists[`${key}__${enumName}`] ? '재생성' : '생성'}
                    </Button>
                  </Table.Cell>
                </Table.Row>
              )),
            )}
          </Table.Body>
        </Table>
      </Panel>
    </div>
  );
}
