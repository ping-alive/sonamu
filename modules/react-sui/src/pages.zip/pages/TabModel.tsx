import React, { useEffect, useState } from 'react';
import { Table, TableBody, TableCell, TableRow } from 'semantic-ui-react';
import { TypeframeTabProps } from 'src/pages/typeframe/TypeframeTabs';
import { GenerateModelModal } from 'src/typeframe/components/GenerateModelModal';
import { OpenVscodeButton } from 'src/typeframe/components/OpenVscodeButton';
import { Panel } from 'src/typeframe/components/Panel';

type TabModelProps = {} & TypeframeTabProps;
export function TabModel({ currentMdId, spec }: TabModelProps) {
  return (
    <div className="tab-model">
      <Panel
        title="API"
        buttons={
          <>
            {spec.exists.model && (
              <OpenVscodeButton
                mdId={currentMdId}
                templateKey="model"
                label="Model"
              />
            )}
            {spec.exists.service__web && (
              <OpenVscodeButton
                mdId={currentMdId}
                templateKey="service"
                label="Web-Service"
                target="web"
              />
            )}
          </>
        }
      >
        {
          <GenerateModelModal
            exists={spec.exists.model ?? false}
            mdId={currentMdId}
            spec={spec}
          />
        }
        {spec.apis.length > 0 && (
          <Table celled>
            <TableBody>
              {spec.apis.map((api) => (
                <TableRow key={api.methodName}>
                  <TableCell>
                    <strong>
                      {api.modelName}.{api.methodName}
                    </strong>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Panel>
    </div>
  );
}
