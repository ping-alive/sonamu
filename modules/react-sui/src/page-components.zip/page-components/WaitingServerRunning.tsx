import axios from 'axios';
import React, { useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Dimmer, Loader } from 'semantic-ui-react';
import { useSWRConfig } from 'swr';

type WaitingServerRunningProps = {};
export function WaitingServerRunning(props: WaitingServerRunningProps) {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { mutate } = useSWRConfig();

  useEffect(() => {
    const intv = setInterval(() => {
      axios({
        url: '/api/healthcheck',
        timeout: 450,
      })
        .then(() => {
          clearInterval(intv);
          const mdId = searchParams.get('mdId') ?? 'typeframe';
          const menu = searchParams.get('menu') ?? 'info';
          navigate(`/typeframe/${mdId}/${menu}`);
          mutate(['/api/typeframe/getSimpleMDSpecs', '']);
        })
        .catch(() => {
          console.log('waiting more 500ms');
        });
    }, 500);
    return () => clearInterval(intv);
  }, []);

  return (
    <Dimmer active={true} page>
      <Loader size="huge">Server is on restarting...</Loader>
    </Dimmer>
  );
}
