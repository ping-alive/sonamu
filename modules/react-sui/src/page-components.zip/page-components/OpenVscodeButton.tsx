import React from 'react';
import {
  Button,
  SemanticCOLORS,
  SemanticICONS,
  SemanticSIZES,
} from 'semantic-ui-react';
import { TypeframeService } from 'src/services/typeframe/typeframe.service';
import { TemplateKey } from 'src/services/typeframe/typeframe.types';

type OpenVscodeButtonProps = {
  mdId: string;
  templateKey: TemplateKey;
  target?: 'web' | 'api';
  icon?: SemanticICONS;
  size?: SemanticSIZES;
  color?: SemanticCOLORS;
  label?: string;
};
export function OpenVscodeButton({
  mdId,
  templateKey,
  target,
  icon,
  size,
  label,
  color,
}: OpenVscodeButtonProps) {
  const handleClick = () => {
    TypeframeService.openVscodeFor(templateKey, mdId, target)
      .then(() => {
        console.log(`${mdId} - ${templateKey} - done`);
      })
      .catch((e) => {
        alert(e.message);
      });
  };

  return (
    <Button
      size={size ?? 'tiny'}
      icon={icon ?? 'code'}
      color={color ?? 'blue'}
      label={label}
      onClick={handleClick}
    />
  );
}
