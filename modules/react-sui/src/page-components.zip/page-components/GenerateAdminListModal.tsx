import React, { useState } from "react";
import ReactJson from "react-json-view";
import { useNavigate } from "react-router-dom";
import { Button, Dropdown, Form, Input, Modal } from "semantic-ui-react";
import { TypeframeService } from "src/services/typeframe/typeframe.service";
import {
  MDSpec,
  TemplateOptions,
} from "src/services/typeframe/typeframe.types";
import { useTypeForm } from "@sonamu/react-sui";

type GenerateAdminListProps = {
  mdId: string;
  spec: MDSpec;
  triggerButtonLabel?: string;
};
export function GenerateAdminList({
  mdId,
  spec,
  triggerButtonLabel = "백오피스 리스트 스캐폴딩",
}: GenerateAdminListProps) {
  // enums
  const { enums } = spec;
  const searchFields = enums[`${mdId}SearchField`].values as string[];
  const orderBys = enums[`${mdId}OrderBy`].values as string[];

  const [open, setOpen] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const navigate = useNavigate();

  const { register, form } = useTypeForm(TemplateOptions.shape.view_list, {
    mdId,
  });

  const requestGenerate = (overwrite: boolean) => {
    if (form.mdId === "") {
      return;
    }

    const timeoutId = setTimeout(() => {
      navigate(`/typeframe/waiting?mdId=${form.mdId}&menu=component`);
    }, 500);

    setLoading(true);
    TypeframeService.generateTemplate("view_list", form, {
      overwrite,
    })
      .then(() => {
        setLoading(false);
      })
      .catch((e) => {
        if (
          overwrite === false &&
          e.message === "이미 경로에 파일이 존재합니다."
        ) {
          setLoading(false);
          clearTimeout(timeoutId);
          if (confirm("이미 경로에 파일이 존재합니다.\n덮어쓰시겠습니까?")) {
            requestGenerate(true);
          } else {
            setOpen(false);
          }
        }
      });
  };

  return (
    <Modal
      onClose={() => setOpen(false)}
      onOpen={() => setOpen(true)}
      open={open}
      centered={false}
      trigger={<Button color="purple">{triggerButtonLabel}</Button>}
    >
      <Modal.Header>{mdId} 백오피스 리스트 스캐폴딩</Modal.Header>
      <Modal.Content>
        <Modal.Description>
          <Form>
            <Form.Field>
              <label>ID (camel)</label>
              <Input placeholder="mdId" {...register("mdId")} />
            </Form.Field>
          </Form>
        </Modal.Description>
      </Modal.Content>
      <Modal.Actions>
        <Button negative onClick={() => setOpen(false)}>
          취소
        </Button>
        <Button
          color="teal"
          onClick={() => requestGenerate(false)}
          loading={loading}
        >
          생성
        </Button>
      </Modal.Actions>
    </Modal>
  );
}
