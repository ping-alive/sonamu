import { capitalize } from 'lodash';
import React from 'react';
import { Link, useLocation, useParams } from 'react-router-dom';
import { Button, Dimmer, Loader } from 'semantic-ui-react';
import { TabComponent } from 'src/pages/typeframe/TabComponent';
import { TabInfo } from 'src/pages/typeframe/TabInfo';
import { TabModel } from 'src/pages/typeframe/TabModel';
import { TypeframeService } from 'src/services/typeframe/typeframe.service';
import { MDSpec } from 'src/services/typeframe/typeframe.types';

export type TypeframeTabProps = {
  currentMdId: string;
  spec: MDSpec;
};
export function TypeframeTabs() {
  const { mdId } = useParams();
  const location = useLocation();
  const [, , currentMdId, currentTabMenu] = location.pathname.split('/');
  const { data: spec, error } = TypeframeService.useMDSpec(currentMdId);

  type TabButton = {
    key: 'info' | 'model' | 'component';
    label: string;
    comp: (prop: TypeframeTabProps) => JSX.Element;
  };
  const tabButtons: TabButton[] = [
    {
      key: 'info',
      label: '정보',
      comp: TabInfo,
    },
    {
      key: 'model',
      label: '모델',
      comp: TabModel,
    },
    {
      key: 'component',
      label: '컴포넌트',
      comp: TabComponent,
    },
  ];

  const tabButton = tabButtons.find(
    (tabButton) => tabButton.key === currentTabMenu,
  );
  if (!tabButton) {
    return <></>;
  }
  const ChildComponent = tabButton.comp;

  return (
    <>
      <div className="tab-buttons">
        <h4>{capitalize(currentMdId)}</h4>
        {tabButtons.map((tabButton) => (
          <Button
            key={tabButton.key}
            color={currentTabMenu === tabButton.key ? 'teal' : undefined}
            active={currentTabMenu === tabButton.key}
            as={Link}
            to={`/typeframe/${mdId}/${tabButton.key}`}
          >
            {tabButton.label}
          </Button>
        ))}
      </div>
      <div className="p-8">
        {error ? (
          <div>Error</div>
        ) : !spec ? (
          <Loader active style={{ marginLeft: 100 }} />
        ) : (
          <ChildComponent
            {...{
              currentMdId,
              spec,
            }}
          ></ChildComponent>
        )}
      </div>
    </>
  );
}
