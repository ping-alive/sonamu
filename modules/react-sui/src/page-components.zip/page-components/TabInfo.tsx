import React, { useEffect, useState } from 'react';
import ReactJson from 'react-json-view';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Accordion,
  Button,
  Dimmer,
  Divider,
  Grid,
  GridColumn,
  GridRow,
  Header,
  Label,
  Loader,
  Segment,
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableHeaderCell,
  TableRow,
} from 'semantic-ui-react';
import { TypeframeTabProps } from 'src/pages/typeframe/TypeframeTabs';
import { TypeframeService } from 'src/services/typeframe/typeframe.service';
import { MDSpec, TemplateKey } from 'src/services/typeframe/typeframe.types';
import { OpenVscodeButton } from 'src/typeframe/components/OpenVscodeButton';
import { Panel } from 'src/typeframe/components/Panel';

type TabInfoProps = {} & TypeframeTabProps;
export function TabInfo({ currentMdId, spec }: TabInfoProps) {
  const [openTypeIndex, setOpenTypeIndex] = useState<number | undefined>();

  return (
    <div className="tab-info">
      <Grid>
        <GridRow columns={2}>
          <GridColumn>
            <Panel
              noMargin
              headerProps={{ textAlign: 'left' }}
              title="#Props"
              buttons={<OpenVscodeButton mdId={currentMdId} templateKey="md" />}
            >
              <Table celled>
                <TableHeader>
                  <TableRow>
                    <TableHeaderCell collapsing>Name</TableHeaderCell>
                    <TableHeaderCell>Type</TableHeaderCell>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {spec.props.map((prop) => (
                    <TableRow key={prop.name}>
                      <TableCell>
                        <strong>{prop.name}</strong>
                      </TableCell>
                      <TableCell>{prop.type}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Panel>
          </GridColumn>
          <GridColumn>
            <Panel
              noMargin
              headerProps={{ textAlign: 'left' }}
              title="#Enums"
              buttons={
                <OpenVscodeButton mdId={currentMdId} templateKey="init_enums" />
              }
            >
              <Table celled>
                <TableHeader>
                  <TableRow>
                    <TableHeaderCell collapsing>Name</TableHeaderCell>
                    <TableHeaderCell>Values</TableHeaderCell>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Object.keys(spec.enums).map((name) => (
                    <TableRow key={name}>
                      <TableCell>
                        <strong>{name}</strong>
                      </TableCell>
                      <TableCell>
                        {spec.enums[name].values.map((value, index) => (
                          <Label key={index} color="violet">
                            {value}
                          </Label>
                        ))}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Panel>
          </GridColumn>
        </GridRow>
        <GridRow columns={1}>
          <GridColumn>
            <Panel
              noMargin
              headerProps={{ textAlign: 'left' }}
              title="#Subsets"
              buttons={<OpenVscodeButton mdId={currentMdId} templateKey="md" />}
            >
              <Table celled>
                <TableHeader>
                  <TableRow>
                    <TableHeaderCell>Name</TableHeaderCell>
                    <TableHeaderCell>Fields</TableHeaderCell>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Object.keys(spec.subsets).map((name) => (
                    <TableRow key={name}>
                      <TableCell>
                        <strong>{name}</strong>
                      </TableCell>
                      <TableCell>
                        {spec.subsets[name].map((value, index) => (
                          <Label key={index}>{value}</Label>
                        ))}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Panel>
          </GridColumn>
        </GridRow>
        <GridRow columns={1}>
          <GridColumn>
            <Panel
              noMargin
              headerProps={{ textAlign: 'left' }}
              title="#Types"
              buttons={
                <OpenVscodeButton mdId={currentMdId} templateKey="init_types" />
              }
            >
              <Table celled>
                <TableHeader>
                  <TableRow>
                    <TableHeaderCell>Name</TableHeaderCell>
                    <TableHeaderCell>Values</TableHeaderCell>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Object.keys(spec.types).map((name, index) => (
                    <TableRow key={name}>
                      <TableCell collapsing>
                        <strong>{name}</strong>
                      </TableCell>
                      <TableCell>
                        <Accordion>
                          <Accordion.Title
                            onClick={() => {
                              setOpenTypeIndex(
                                openTypeIndex === index ? undefined : index,
                              );
                            }}
                          >
                            {name}
                          </Accordion.Title>
                          <Accordion.Content active={openTypeIndex === index}>
                            <ReactJson src={spec.types[name]} />
                          </Accordion.Content>
                        </Accordion>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Panel>
          </GridColumn>
        </GridRow>
      </Grid>
    </div>
  );
}
