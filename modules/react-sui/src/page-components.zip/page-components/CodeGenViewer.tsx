import React, { useEffect, useState } from 'react';
import ReactJson from 'react-json-view';
import {
  Button,
  Dropdown,
  DropdownProps,
  Form,
  FormField,
  Header,
  Segment,
} from 'semantic-ui-react';
import { TypeframeService } from 'src/services/typeframe/typeframe.service';
import {
  PathAndCode,
  TemplateKey,
  TemplateOptions,
} from 'src/services/typeframe/typeframe.types';
import { ButtonSet, ButtonSetProps } from 'src/typeframe/components/ButtonSet';

// import { Light as SyntaxHighlighter } from 'react-syntax-highlighter';
// import ts from 'react-syntax-highlighter/dist/esm/languages/hljs/typescript';
// import railscasts from 'react-syntax-highlighter/dist/esm/styles/hljs/railscasts';
// SyntaxHighlighter.registerLanguage('typescript', ts);

type CodeGenViewerProps = {};
export function CodeGenViewer(props: CodeGenViewerProps) {
  const [templateKey, setTemplateKey] = useState<TemplateKey>('md');
  const [isLoading, setLoading] = useState<boolean>(false);

  const mdId = 'Product';
  const enumId = 'ProductSite';
  const idConstant = 'SITE';
  const [options] = useState<TemplateOptions>({
    md: {
      mdId,
      title: '상품',
    },
    init_enums: { mdId },
    init_types: { mdId },
    init_generated: { mdId },
    generated: { mdId: 'Post' },
    model: {
      mdId: 'Post',
      defaultOrderBy: 'id-desc',
      defaultSearchField: 'title',
    },
    bridge: {
      mdId: 'Deal',
    },
    model_test: { mdId: 'Post' },
    service: { mdId: 'Post' },
    view_list: {
      mdId,
    },
    view_form: { mdId },
    view_id_all_select: { mdId },
    view_id_async_select: { mdId, textField: 'title' },
    view_enums_select: { mdId, enumId, idConstant },
    view_enums_dropdown: { mdId, enumId, idConstant },
    view_enums_buttonset: { mdId, enumId, idConstant },
    view_search_input: { mdId },
    view_list_columns: {
      mdId,
      columns: [{ name: 'one', label: 'One', tc: 'any' }],
      columnImports: '',
    },
    generated_http: { mdId },
  });
  const [templateResult, setTemplateResult] = useState<PathAndCode>();

  const handleRefresh = () => {
    setLoading(true);
    TypeframeService.renderTemplate(templateKey, options[templateKey])
      .then((result) => {
        setTemplateResult(result);
      })
      .catch((e) => {
        console.error(e);
      })
      .finally(() => {
        setLoading(false);
      });
  };

  useEffect(() => {
    handleRefresh();
  }, [templateKey]);

  return (
    <div className="codegen-viewer">
      <Segment className="params">
        <Header>Params</Header>
        <Form>
          <FormField className="template-key-form-field">
            <label>템플릿 키</label>
            <TemplateKeyButtonSet
              value={templateKey}
              onChange={(e, prop) => {
                if (prop.value !== undefined) {
                  setTemplateKey(prop.value as TemplateKey);
                }
              }}
            />
          </FormField>
          <ReactJson
            src={{
              templateKey,
              options: options[templateKey],
            }}
          />
          <FormField className="submit-form-field">
            <Button
              fluid
              icon="arrow alternate circle right"
              color="teal"
              onClick={handleRefresh}
            />
          </FormField>
        </Form>
      </Segment>
      <Segment className="viewer" loading={isLoading}>
        <Header>Code</Header>
        <div className="path">{templateResult?.path}</div>
        <div
          className="code"
          style={{ whiteSpace: 'pre-line', color: 'white' }}
        >
          {templateResult && <pre>{templateResult.code}</pre>}
          {/* {templateResult && (
            <SyntaxHighlighter
              language={ts}
              showLineNumbers={true}
              style={railscasts}
            >
              {templateResult.code}
            </SyntaxHighlighter>
          )} */}
        </div>
      </Segment>
    </div>
  );
}

type TemplateKeyButtonSetProps = ButtonSetProps & {};
export function TemplateKeyButtonSet(props: TemplateKeyButtonSetProps) {
  const options = TemplateKey.options.map((key) => {
    return {
      value: key,
      text: key.toUpperCase(),
    };
  });
  return (
    <ButtonSet options={options} buttonProps={{ size: 'tiny' }} {...props} />
  );
}
