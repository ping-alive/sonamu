import React from 'react';
import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { Button, Loader } from 'semantic-ui-react';
import { TypeframeService } from 'src/services/typeframe/typeframe.service';
import { GenerateMdModal } from 'src/typeframe/components/GenerateMdModal';
export function TypeframeLayout() {
  const location = useLocation();
  const [, , currentMdId, currentTabMenu] = location.pathname.split('/');

  const {
    data: simpleSpecs,
    error,
    mutate,
  } = TypeframeService.useSimpleMDSpecs();

  const navigate = useNavigate();

  return (
    <div className="typeframe-layout">
      <div className="sidemenu">
        <h2>TypeFrame MD</h2>
        {error ? (
          <div>Cannot Load SimpleSpecs</div>
        ) : !simpleSpecs ? (
          <Loader />
        ) : (
          simpleSpecs.map((spec) => (
            <Link
              key={spec.mdId}
              to={`/typeframe/${spec.mdId}/${currentTabMenu ?? 'info'}`}
            >
              <li className={currentMdId === spec.mdId ? 'active' : ''}>
                {spec.mdId} &nbsp;<span className="title">{spec.title}</span>
              </li>
            </Link>
          ))
        )}
        <div className="divider"></div>
        <div className="others px-2">
          <Button fluid icon="write" as={Link} to="/typeframe/codegen" />
        </div>
        <div className="side-buttons">
          <Button inverted icon="arrow left" onClick={() => navigate('/')} />
          <Button inverted icon="refresh" onClick={() => mutate()} />
          <GenerateMdModal />
        </div>
      </div>
      <div className="content">
        <Outlet />
      </div>
    </div>
  );
}
