import React, {
  CSSProperties,
  MutableRefObject,
  useRef,
  useState,
  useEffect,
} from "react";
import {
  Input,
  Button,
  Form,
  Label,
  Container,
  Segment,
  Header,
  Divider,
} from "semantic-ui-react";
import { TypeframeService } from "src/services/typeframe/typeframe.service";
import Convert from "ansi-to-html";
import { uniq } from "lodash";

type WebShellProps = { style?: CSSProperties };
export function WebShell({ style }: WebShellProps) {
  /* TODO */
  return <>WebShell</>;
  // const [cmd, setCmd] = useState<string>('ls -lah');
  // const [histories, setHistories] = useState<string[]>([
  //   'yarn node dist/practices/p1-chalk.js',
  //   'pwd',
  //   'cat package.json',
  //   'df -H',
  // ]);
  // const [terminal, setTerminal] = useState<string>('');
  // const ref = useRef<Input | null>();

  // useEffect(() => {
  //   handleRunCommand();
  // }, []);

  // const handleRunCommand = (injectCmd?: string) => {
  //   const currentCmd = injectCmd ?? cmd;
  //   if (currentCmd === '') {
  //     return;
  //   }

  //   setTerminal('');
  //   setCmd('');
  //   setHistories((h) => uniq([currentCmd, ...h]));

  //   TypeframeService.runShellCommand(currentCmd).then((response) => {
  //     if (response.body === null) {
  //       return;
  //     }

  //     const reader = response.body.getReader();
  //     const decoder = new TextDecoder();
  //     const readChunk = (): Promise<
  //       ReadableStreamDefaultReadResult<Uint8Array> | string
  //     > => {
  //       return reader
  //         .read()
  //         .then((result: ReadableStreamDefaultReadResult<Uint8Array>) => {
  //           const chunk = decoder.decode(result.value || new Uint8Array(), {
  //             stream: !result.done,
  //           });
  //           setTerminal((r) => r + chunk);

  //           if (result.done) {
  //             ref.current && ref.current.focus();
  //             return 'DONE';
  //           } else {
  //             return readChunk();
  //           }
  //         });
  //     };

  //     return readChunk();
  //   });
  // };

  // return (
  //   <Segment style={style}>
  //     <Header textAlign="left" color="blue">
  //       WebShell
  //     </Header>
  //     <div className="flex">
  //       <Input
  //         fluid
  //         value={cmd}
  //         onChange={(e, data) => setCmd(data.value)}
  //         onKeyUp={(e: KeyboardEvent) =>
  //           e.key === 'Enter' && handleRunCommand()
  //         }
  //         action={<Button onClick={() => handleRunCommand()}>실행</Button>}
  //         ref={ref as MutableRefObject<Input | null>}
  //         style={{ flex: 1 }}
  //       />
  //     </div>
  //     <TerminalView
  //       style={{ minHeight: 400 }}
  //       cmd={histories[0]}
  //       output={terminal}
  //     />
  //     <div className="histories">
  //       {histories.map((history, index) => (
  //         <Button
  //           key={index}
  //           size="tiny"
  //           color={index === 0 ? 'grey' : undefined}
  //           onClick={() => {
  //             handleRunCommand(history);
  //           }}
  //         >
  //           {history}
  //         </Button>
  //       ))}
  //     </div>
  //   </Segment>
  // );
}

type TerminalViewProps = {
  cmd: string;
  output: string;
  style?: CSSProperties;
};
export function TerminalView({ cmd, output, style }: TerminalViewProps) {
  const convert = new Convert();
  return (
    <div
      className="terminal-view"
      style={{
        backgroundColor: "#222",
        color: "#ccc",
        padding: ".8em 1.2em",
        margin: "1em 0",
        marginTop: ".3em",
        ...style,
      }}
    >
      <h4 style={{ color: "white" }}>{cmd}</h4>
      <pre dangerouslySetInnerHTML={{ __html: convert.toHtml(output) }}></pre>
    </div>
  );
}
