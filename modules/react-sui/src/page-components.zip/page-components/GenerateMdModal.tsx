import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button, Form, Input, Modal } from "semantic-ui-react";
import { TypeframeService } from "src/services/typeframe/typeframe.service";
import { TemplateOptions } from "src/services/typeframe/typeframe.types";
import { useTypeForm } from "@sonamu/react-sui";

type GenerateMdModalProps = {};
export function GenerateMdModal(props: GenerateMdModalProps) {
  const [open, setOpen] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const navigate = useNavigate();

  const { register, form } = useTypeForm(TemplateOptions.shape.md, {
    mdId: "Product",
    title: "상품",
  });

  const callGenerateMD = (overwrite: boolean) => {
    if (form.mdId === "" || form.title === "") {
      return;
    }

    const timeoutId = setTimeout(() => {
      setOpen(false);
      navigate(`/typeframe/waiting?mdId=${form.mdId}&menu=info`);
    }, 1500);

    setLoading(true);
    TypeframeService.generateTemplate("md", form, {
      overwrite,
    })
      .then(() => {
        setLoading(false);
      })
      .catch((e) => {
        if (
          overwrite === false &&
          e.message === "이미 경로에 파일이 존재합니다."
        ) {
          clearTimeout(timeoutId);
          if (confirm("이미 경로에 파일이 존재합니다.\n덮어쓰시겠습니까?")) {
            callGenerateMD(true);
          } else {
            setOpen(false);
          }
        }
        setLoading(false);
      });
  };

  return (
    <Modal
      onClose={() => setOpen(false)}
      onOpen={() => setOpen(true)}
      open={open}
      centered={false}
      trigger={
        <Button inverted className="btn-add-md">
          MD 추가
        </Button>
      }
    >
      <Modal.Header>MD 추가</Modal.Header>
      <Modal.Content>
        <Modal.Description>
          <Form>
            <Form.Field>
              <label>ID (camel)</label>
              <Input placeholder="mdId" {...register("mdId")} />
            </Form.Field>
            <Form.Field>
              <label>타이틀</label>
              <Input placeholder="타이틀" {...register("title")} />
            </Form.Field>
          </Form>
        </Modal.Description>
      </Modal.Content>
      <Modal.Actions>
        <Button negative onClick={() => setOpen(false)}>
          취소
        </Button>
        <Button
          color="teal"
          onClick={() => callGenerateMD(false)}
          loading={loading}
        >
          생성
        </Button>
      </Modal.Actions>
    </Modal>
  );
}
